import { Box, Paper } from '@mui/material';
import ProfileManagementDetail from '../components/profiles/ProfileManagementDetail';
import useProfileStore from '../stores/profileStore';
import { useEffect } from 'react';
import useAuthStore from '../stores/authStore';

export default function ProfileMamagementPage() {
  const { authentication } = useAuthStore();
  const { profile, fetchProfile, clear, updateProfile } = useProfileStore();

  useEffect(() => {
    if (authentication) {
      fetchProfile(authentication.userId);
    }
    return () => {
      clear();
    };
  }, [fetchProfile, authentication]);

  return (
    <Box
      sx={{
        width: '100%',
        height: '100%',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
      }}
    >
      <Paper elevation={1} sx={{ p: 4, width: '100%', height: '100%' }}>
        <Box sx={{ width: '100%', maxWidth: '500px', margin: '0 auto' }}>
          {profile && <ProfileManagementDetail profile={profile} updateProfile={updateProfile} />}
        </Box>
      </Paper>
    </Box>
  );
}
