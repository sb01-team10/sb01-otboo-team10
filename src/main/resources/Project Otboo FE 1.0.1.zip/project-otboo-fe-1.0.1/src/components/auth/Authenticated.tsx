import { useEffect } from 'react';
import { Outlet } from 'react-router';
import useAuthStore from '../../stores/authStore';
import { useNavigate } from 'react-router';
import { ROUTE_OBJECTS } from '../../router';

export default function Authenticated() {
  const { authentication, isAuthenticated, fetchMe } = useAuthStore();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isAuthenticated || !authentication) {
      fetchMe().then((result) => {
        if (!result) {
          navigate(ROUTE_OBJECTS.signIn.path);
        }
      });
    }
  }, [isAuthenticated, authentication, navigate, fetchMe]);

  if (!isAuthenticated || !authentication) {
    return null;
  }

  return <Outlet />;
}
