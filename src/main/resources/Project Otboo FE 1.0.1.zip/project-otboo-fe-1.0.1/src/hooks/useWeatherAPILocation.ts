import { useCallback, useState } from 'react';
import { getWeatherLocation } from '../api/weathers';
import type { WeatherAPILocation } from '../types/common';

export default function useWeatherAPILocation(initialLocation?: WeatherAPILocation | null) {
  const [location, setLocation] = useState<WeatherAPILocation | null | undefined>(initialLocation);

  const refetchLocation = useCallback(async () => {
    const geoLocation = navigator.geolocation;
    if (!geoLocation) return;

    geoLocation.getCurrentPosition(async (position) => {
      const location = await getWeatherLocation({
        longitude: position.coords.longitude,
        latitude: position.coords.latitude,
      });
      setLocation(location);
    });
  }, []);

  return { location, refetchLocation, setLocation };
}
